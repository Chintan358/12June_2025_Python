from django.contrib import admin
from crudapp.models import *
# Register your models here.
admin.site.register(Employee)
